﻿using UnityEngine;

public class PlayerMovent : MonoBehaviour {
    [SerializeField] private float _speed;
    private Rigidbody2D _playerPhysics;
    private bool _seeToRight = true;

    [Header("Jump Comtroll Fields")]
    [SerializeField] private Transform _feetPos;
    [SerializeField] private LayerMask _whoISLayer;
    [SerializeField] private float _checkRadius;
    [SerializeField] private float _jumpForce;
    private bool _isGrounded;

	private void Start ()
    {
        _playerPhysics = GetComponent<Rigidbody2D>();
	}
	
	private void Update ()
    {
        float _xOrientaiton = Input.GetAxis("Horizontal");
        _playerPhysics.velocity = new Vector2(_speed * _xOrientaiton, _playerPhysics.velocity.y);

        if (_xOrientaiton < 0 && _seeToRight == true)
        {
            Flip();
        }
        else if(_xOrientaiton > 0 && _seeToRight == false)
        {
            Flip();
        }
	}
    private void FixedUpdate()
    {
        _isGrounded = Physics2D.OverlapCircle(_feetPos.position, _checkRadius, _whoISLayer);

        if (_isGrounded)
        {
            if (Input.GetKey(KeyCode.Space))
            {
                _playerPhysics.velocity = Vector2.up * _jumpForce;
            }
        }
    }
    private void Flip()
    {
        Vector3 _scale = transform.localScale;
        _scale.x *= -1;
        transform.localScale = _scale;
        _seeToRight = !_seeToRight;
    }
}
